
"use client";
import Image from "next/image";
import { motion } from "framer-motion";
import { Leaf, Pencil, CreditCard, ShoppingCart, ShieldCheck, Truck, Star, Lock, MessageCircle, Users, MapPin, Clock } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

const MP_LINK_DEFAULT = "https://mpago.la/XXXXXXXX"; // Reemplazar por links reales
const WHATSAPP_LINK = "https://wa.me/598990320538?text=Hola%20CitroVida%2C%20quiero%20hacer%20una%20consulta";

const DEPARTAMENTOS_UY = ["Artigas","Canelones","Cerro Largo","Colonia","Durazno","Florida","Flores","Lavalleja","Maldonado","Montevideo","Paysandú","Río Negro","Rivera","Rocha","Salto","San José","Soriano","Tacuarembó","Treinta y Tres"];

const tarifasEnvio = (depto: string) => {
  if (!depto) return 0;
  if (depto === "Montevideo") return 190;
  return 290;
};

export default function CitronellaLandingPage() {
  const currency = new Intl.NumberFormat("es-UY", { style: "currency", currency: "UYU" });
  const [editMode, setEditMode] = useState(false);

  const productos = [
    { id:1, sku:"CIT-TERRA", nombre:"Vela Terracota", desc:"Exterior", precio:390, img:"terracota.png", mp: MP_LINK_DEFAULT },
    { id:2, sku:"CIT-ANT", nombre:"Antorcha Jardín", desc:"116 cm", precio:299, img:"antorcha_jardin.png", mp: MP_LINK_DEFAULT },
    { id:3, sku:"CIT-FRAS-GOLD", nombre:"Vela en Frasco Tapa Dorada", desc:"Soja", precio:620, img:"frasco_tapa.png", mp: MP_LINK_DEFAULT },
    { id:4, sku:"CIT-7DIAS", nombre:"Vela 7 días", desc:"Uso prolongado", precio:990, img:"vela_7_dias.png", mp: MP_LINK_DEFAULT },
    { id:5, sku:"CIT-TEA6", nombre:"Tealights x6", desc:"Pack económico", precio:450, img:"tealights_6.png", mp: MP_LINK_DEFAULT },
    { id:6, sku:"CIT-TEAGR", nombre:"Tealights a granel", desc:"Mayorista", precio:4990, img:"tealights_granel.png", mp: MP_LINK_DEFAULT },
    { id:7, sku:"CIT-CUENCO", nombre:"Vela Cuenco Madera", desc:"Deco artesanal", precio:1890, img:"cuenco_madera.png", mp: MP_LINK_DEFAULT },
    { id:8, sku:"CIT-DIF", nombre:"Difusor Citronella", desc:"Aromaterapia", precio:5508, img:"difusor_saphirus.png", mp: MP_LINK_DEFAULT },
    { id:9, sku:"CIT-ESEN", nombre:"Esencias para hornillos", desc:"10 ml", precio:2489, img:"esencias_hornillo.png", mp: MP_LINK_DEFAULT },
    { id:10, sku:"CIT-REPEL", nombre:"Spray Repelente 250 ml", desc:"Biodegradable", precio:8075, img:"repelente.png", mp: MP_LINK_DEFAULT },
    { id:11, sku:"CIT-PISO1", nombre:"Desodorante Piso 1 L", desc:"Concentrado", precio:3290, img:"piso_1l.png", mp: MP_LINK_DEFAULT },
    { id:12, sku:"CIT-PISO2X3", nombre:"Desodorante Piso 2 L x3", desc:"Pack", precio:8990, img:"piso_pack2l.png", mp: MP_LINK_DEFAULT },
    { id:13, sku:"CIT-ANT-MESA", nombre:"Antorcha Mesa Bambú", desc:"Decorativa", precio:11990, img:"antorcha_mesa_bambu.png", mp: MP_LINK_DEFAULT },
    { id:14, sku:"CIT-KIT-ACEITE", nombre:"Kit Aceite + frascos/mechas", desc:"DIY", precio:24628, img:"kit_aceite_1l.png", mp: MP_LINK_DEFAULT },
    { id:15, sku:"CIT-KIT-JARDIN", nombre:"Kit Jardín sahumerios+aceite", desc:"Combo", precio:35175, img:"kit_sahumerios_aceite.png", mp: MP_LINK_DEFAULT },
    { id:16, sku:"CIT-JABONES", nombre:"Jabones Artesanales", desc:"Cuidado personal", precio:52800, img:"jabones_vert.png", mp: MP_LINK_DEFAULT },
  ] as const;

  const [cart, setCart] = useState<{id:number; qty:number;}[]>([]);
  const [depto, setDepto] = useState("");
  const [retiroLocal, setRetiroLocal] = useState(false);
  const [notas, setNotas] = useState("");

  // WhatsApp tip
  const [showTip, setShowTip] = useState(false);
  useEffect(() => {
    const k = "citrovida_whatsapp_tip_shown";
    if (!sessionStorage.getItem(k)) {
      const t1 = setTimeout(() => setShowTip(true), 1500);
      const t2 = setTimeout(() => setShowTip(false), 12000);
      sessionStorage.setItem(k, "1");
      return () => { clearTimeout(t1); clearTimeout(t2); };
    }
  }, []);

  const addToCart = (id:number) => {
    setCart(prev => {
      const e = prev.find(i => i.id === id);
      if (e) return prev.map(i => i.id===id?{...i, qty:i.qty+1}:i);
      return [...prev, {id, qty:1}];
    });
  };
  const updateQty = (id:number, qty:number) => qty<=0? setCart(prev=>prev.filter(i=>i.id!==id)) : setCart(prev=>prev.map(i=>i.id===id?{...i, qty}:i));

  const cartLines = useMemo(() => cart.map(l => {
    const p = productos.find(x => x.id === l.id)!;
    const lineTotal = p.precio * l.qty;
    return {...p, qty:l.qty, lineTotal};
  }), [cart]);

  const subtotal = useMemo(() => cartLines.reduce((s,l)=>s+l.lineTotal,0), [cartLines]);
  const envio = useMemo(() => (retiroLocal ? 0 : tarifasEnvio(depto)), [depto, retiroLocal]);
  const total = subtotal + envio;

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="flex justify-between items-center p-6 shadow-md bg-white sticky top-0 z-50">
        <div className="flex items-center space-x-2">
          <Leaf className="text-green-600 w-6 h-6" />
          <h1 className="text-2xl font-bold text-green-700">CitroVida</h1>
        </div>
        <nav className="hidden md:flex space-x-4">
          <a href="#quienes" className="hover:text-green-600">Quiénes somos</a>
          <a href="#productos" className="hover:text-green-600">Productos</a>
          <a href="#checkout" className="hover:text-green-600">Checkout</a>
          <a href="#faq" className="hover:text-green-600">FAQ</a>
        </nav>
        <div className="flex items-center gap-2">
          <Button variant="outline" className="rounded-2xl" onClick={()=>setEditMode(v=>!v)}>
            <Pencil className="w-4 h-4 mr-2" /> {editMode? "Ocultar edición":"Editar precios"}
          </Button>
          <a href="#checkout">
            <Button className="rounded-2xl"><ShoppingCart className="w-4 h-4 mr-2"/>Carrito ({cart.reduce((s,c)=>s+c.qty,0)})</Button>
          </a>
        </div>
      </header>

      {/* WhatsApp Floating */}
      <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer"
         className="fixed bottom-6 right-6 bg-green-500 hover:bg-green-600 text-white p-4 rounded-full shadow-lg z-50 flex items-center justify-center"
         aria-label="WhatsApp">
        <MessageCircle className="w-6 h-6" />
      </a>
      {showTip && (
        <motion.div initial={{opacity:0,y:10}} animate={{opacity:1,y:0}} className="fixed bottom-24 right-6 z-50">
          <div className="bg-white shadow-xl rounded-2xl px-4 py-3 border max-w-xs">
            <p className="text-sm text-gray-800 font-medium">¿Necesitás ayuda?</p>
            <p className="text-xs text-gray-600 mt-1">Escribinos por WhatsApp y te asesoramos al instante.</p>
            <div className="flex justify-end mt-2">
              <button onClick={()=>setShowTip(false)} className="text-xs text-green-700 hover:underline">Cerrar</button>
            </div>
          </div>
        </motion.div>
      )}

      {/* Hero */}
      <motion.section className="flex flex-col items-center text-center py-16 md:py-20 bg-gradient-to-b from-green-100 to-green-200"
        initial={{opacity:0,y:-30}} animate={{opacity:1,y:0}} transition={{duration:0.6}}>
        <h2 className="text-4xl md:text-5xl font-bold text-green-800 mb-4">Bienestar Natural en Cada Gota</h2>
        <p className="max-w-2xl text-lg text-gray-700 mb-6">
          Citronella y Lemongrass directo de <b>destilería</b>. Productos confiables para tu hogar, tu piel y tu entorno.
        </p>
        <div className="flex gap-3 items-center">
          <Button className="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-2xl shadow-lg" onClick={()=>document.getElementById("productos")?.scrollIntoView({behavior:"smooth"})}>Comprar Ahora</Button>
          <div className="flex items-center gap-3 text-sm text-gray-700">
            <ShieldCheck className="w-5 h-5 text-green-700"/> Garantía 7 días
            <Lock className="w-5 h-5 text-green-700"/> Pago seguro
            <Truck className="w-5 h-5 text-green-700"/> Envío a todo UY
          </div>
        </div>
      </motion.section>

      {/* Quienes */}
      <section id="quienes" className="bg-white p-8 md:p-12">
        <div className="max-w-5xl mx-auto text-center">
          <h3 className="text-3xl font-bold text-green-700 mb-4 flex items-center justify-center gap-2">
            <Users className="w-7 h-7 text-green-700"/> Quiénes Somos
          </h3>
          <p className="text-lg text-gray-700 leading-relaxed mb-6">
            <b>CitroVida</b> es un emprendimiento familiar en <b>Salto, Uruguay</b>.<br/>
            Fabricamos aceites esenciales puros y derivados de <b>citronella y lemongrass</b>, <b>directo de destilería</b>.
            Enviamos a todo el país. No trabajamos con representantes en la calle; todas las ventas se coordinan directamente.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
            <Card className="shadow-md"><CardContent>
              <MapPin className="text-green-700 w-6 h-6 mb-2"/><h4 className="font-semibold">Ubicación</h4>
              <p className="text-sm text-gray-600">Salto, Uruguay. Envíos a todo el país.</p>
            </CardContent></Card>
            <Card className="shadow-md"><CardContent>
              <ShieldCheck className="text-green-700 w-6 h-6 mb-2"/><h4 className="font-semibold">Venta Directa</h4>
              <p className="text-sm text-gray-600">Sin representantes. Atención personalizada.</p>
            </CardContent></Card>
            <Card className="shadow-md"><CardContent>
              <Clock className="text-green-700 w-6 h-6 mb-2"/><h4 className="font-semibold">Horarios</h4>
              <p className="text-sm text-gray-600">Lun-Jue 9:00-19:00 · Vie 9:00-16:00</p>
            </CardContent></Card>
          </div>
        </div>
      </section>

      {/* Productos Grid */}
      <section id="productos" className="grid grid-cols-1 md:grid-cols-3 gap-6 p-6 md:p-8">
        {productos.map(prod => (
          <Card key={prod.id} className="rounded-2xl shadow-md hover:shadow-lg transition flex flex-col">
            <CardContent className="flex flex-col items-center p-6 flex-1">
              <Image src={`/products/${prod.img}`} alt={prod.nombre} width={420} height={420}
                     className="mb-4 h-40 w-auto object-contain" />
              <h3 className="text-xl font-semibold mb-1 text-center">{prod.nombre}</h3>
              <p className="text-xs text-gray-500 mb-1">SKU: {prod.sku}</p>
              <div className="flex items-center gap-1 mb-2" aria-label="rating">
                {[...Array(5)].map((_,i)=>(<Star key={i} className="w-4 h-4 fill-green-600 text-green-600"/>))}
                <span className="text-xs text-gray-500">(36)</span>
              </div>
              <p className="text-sm text-gray-600 text-center mb-4">{prod.desc}</p>

              {editMode ? (
                <div className="w-full mb-4">
                  <label className="block text-sm text-gray-600 mb-1">Precio (UYU)</label>
                  <input type="number" min={0} step={10} defaultValue={prod.precio}
                         onChange={(e)=>{ /* edit ephemeral */ prod.precio = Number(e.target.value) }} className="w-full border rounded-lg p-2"/>
                </div>
              ) : (
                <div className="text-2xl font-bold text-green-700 mb-4">{currency.format(prod.precio)}</div>
              )}

              <div className="flex gap-2 w-full">
                <Button className="flex-1 rounded-2xl bg-green-600 hover:bg-green-700" onClick={()=>addToCart(prod.id)}>
                  <ShoppingCart className="w-4 h-4 mr-2"/> Agregar
                </Button>
                <a className="flex-1" href={prod.mp} target="_blank" rel="noopener noreferrer">
                  <Button className="w-full rounded-2xl" variant="outline">
                    <CreditCard className="w-4 h-4 mr-2"/> Comprar ahora
                  </Button>
                </a>
              </div>
              <p className="mt-2 text-xs text-gray-500">Precio estimado y actualizable.</p>
            </CardContent>
          </Card>
        ))}
      </section>

      {/* Checkout */}
      <section id="checkout" className="bg-green-50 p-8 md:p-12">
        <h3 className="text-3xl font-bold text-green-700 mb-6 text-center">Finalizar compra</h3>
        <div className="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2 bg-white rounded-2xl shadow p-4">
            <h4 className="font-semibold mb-3 flex items-center"><ShoppingCart className="w-4 h-4 mr-2"/>Tu carrito</h4>
            {cartLines.length === 0 ? (
              <p className="text-sm text-gray-600">No hay productos en el carrito.</p>
            ) : (
              <div className="space-y-3">
                {cartLines.map(l => (
                  <div key={l.id} className="flex items-center justify-between border-b pb-3">
                    <div>
                      <div className="font-medium">{l.nombre}</div>
                      <div className="text-xs text-gray-500">{currency.format(l.precio)} c/u</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <input type="number" min={1} value={l.qty} onChange={(e)=>updateQty(l.id, Number(e.target.value))} className="w-16 border rounded-lg p-1"/>
                      <div className="w-24 text-right font-semibold">{currency.format(l.lineTotal)}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
            <div className="mt-4">
              <label className="text-sm text-gray-600">Notas del pedido (opcional)</label>
              <textarea value={notas} onChange={(e)=>setNotas(e.target.value)} className="w-full border rounded-lg p-2" rows={3} placeholder="Ej: Entrega por la tarde, timbre roto, etc."/>
            </div>
          </div>

          <div className="bg-white rounded-2xl shadow p-4">
            <h4 className="font-semibold mb-3">Resumen</h4>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between"><span>Subtotal</span><span>{currency.format(subtotal)}</span></div>
              <div className="flex flex-col gap-2">
                <label className="text-gray-600">Departamento</label>
                <select value={depto} onChange={(e)=>setDepto(e.target.value)} className="border rounded-lg p-2">
                  <option value="">Seleccionar…</option>
                  {DEPARTAMENTOS_UY.map(d => (<option key={d} value={d}>{d}</option>))}
                </select>
                <label className="inline-flex items-center gap-2 text-gray-700">
                  <input type="checkbox" checked={retiroLocal} onChange={(e)=>setRetiroLocal(e.target.checked)} />
                  Retiro en local (sin costo)
                </label>
              </div>
              <div className="flex justify-between"><span>Envío</span><span>{retiroLocal?"$0":currency.format(envio)}</span></div>
              <div className="border-t pt-2 flex justify-between font-bold text-green-700"><span>Total</span><span>{currency.format(total)}</span></div>
            </div>
            <a className="block mt-4" href={MP_LINK_DEFAULT} target="_blank" rel="noopener noreferrer">
              <Button className="w-full rounded-2xl bg-green-600 hover:bg-green-700">
                <CreditCard className="w-4 h-4 mr-2"/> Pagar con Mercado Pago
              </Button>
            </a>
            <p className="text-[11px] text-gray-500 mt-2">Al pagar aceptás Términos y Políticas de Devolución (7 días). El valor de envío es estimado.</p>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="bg-white p-8 md:p-12">
        <h3 className="text-3xl font-bold text-green-700 mb-6 text-center">Preguntas frecuentes</h3>
        <div className="max-w-4xl mx-auto space-y-4">
          <details className="bg-green-50 p-4 rounded-xl shadow-sm">
            <summary className="font-semibold cursor-pointer">¿Es natural?</summary>
            <p className="text-sm text-gray-700 mt-2">Sí, directo de destilería. Sin pesticidas.</p>
          </details>
          <details className="bg-green-50 p-4 rounded-xl shadow-sm">
            <summary className="font-semibold cursor-pointer">¿Sirve como repelente?</summary>
            <p className="text-sm text-gray-700 mt-2">Uso tradicional ambiental y tópico diluido. No aplicar sin diluir.</p>
          </details>
          <details className="bg-green-50 p-4 rounded-xl shadow-sm">
            <summary className="font-semibold cursor-pointer">¿Envíos?</summary>
            <p className="text-sm text-gray-700 mt-2">A todo Uruguay. Retiro local sin costo.</p>
          </details>
        </div>
      </section>

      {/* Footer */}
      <footer id="contacto" className="bg-green-700 text-white p-8 text-center">
        <h4 className="text-xl font-semibold mb-2">Contacto</h4>
        <p className="mb-1">Email: contacto@citrovida.uy | Tel/WhatsApp: +598 99 032 0538</p>
        <p className="text-sm text-green-100">Atendemos mayorista y minorista. Facturación con RUT.</p>
      </footer>
    </div>
  );
}
