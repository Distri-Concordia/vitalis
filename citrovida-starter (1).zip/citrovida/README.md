
# CitroVida — Landing + Catálogo (Next.js + Tailwind)

## Cómo correr
```bash
npm install
npm run dev
# abre http://localhost:3000
```
- Reemplazá todos los `https://mpago.la/XXXXXXXX` por tus **links reales**.
- Tus imágenes están en `public/products/` y ya están referenciadas en `app/page.tsx`.

## Deploy recomendado
- Vercel: `npm i -g vercel && vercel`
