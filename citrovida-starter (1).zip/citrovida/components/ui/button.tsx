
import * as React from "react";
function clsx(...a:any[]){return a.filter(Boolean).join(' ');}

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "solid" | "outline";
}

export function Button({ className, variant="solid", ...props }: ButtonProps) {
  const base = "px-4 py-2 rounded-2xl text-sm font-medium transition shadow";
  const solid = "bg-green-600 hover:bg-green-700 text-white";
  const outline = "border border-green-600 text-green-700 hover:bg-green-50";
  return <button className={clsx(base, variant==="solid" ? solid : outline, className)} {...props} />;
}
